package com.virtusa.beans;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {

	@Autowired
	private MembershipdetailsService service; 
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Membershipdetails> listMembershipdetails = service.listAll();
		model.addAttribute("listMembershipdetails", listMembershipdetails);
		
		return "membershipdetailsindex";
	}
	
	@RequestMapping("/new")
	public String showNewMembershipdetailsPage(Model model) {
		Membershipdetails membershipdetails = new Membershipdetails();
		model.addAttribute("membershipdetails", membershipdetails);
		
		return "new_membershipdetails";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveMembershipdetails(@ModelAttribute("membershipdetails") Membershipdetails membershipdetails) {
		service.save(membershipdetails);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditMembershipdetailsPage(@PathVariable(name = "id") int id) {
		ModelAndView mav = new ModelAndView("edit_membershipdetails");
		Membershipdetails membershipdetails = service.get(id);
		mav.addObject("membershipdetails", membershipdetails);
		
		return mav;
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteMembershipdetails(@PathVariable(name = "id") int id) {
		service.delete(id);
		return "redirect:/";		
	}
}
