package com.virtusa.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Membershipdetails {
	private Long id;
	private String name;
	private Long mobile;
	private String membershiptype;
	private float duration;

	protected Membershipdetails() {
	}

	public Membershipdetails(Long id, String name, Long mobile, String membershiptype, float duration) {
		super();
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.membershiptype = membershiptype;
		this.duration = duration;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getMobile() {
		return mobile;
	}

	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}

	public String getMembershiptype() {
		return membershiptype;
	}

	public void setMembershiptype(String membershiptype) {
		this.membershiptype = membershiptype;
	}

	public float getDuration() {
		return duration;
	}

	public void setDuration(float duration) {
		this.duration = duration;
	}
}



	
	
