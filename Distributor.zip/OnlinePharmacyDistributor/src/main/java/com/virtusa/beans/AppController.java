package com.virtusa.beans;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AppController {

	@Autowired
	private DistributorService service; 
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Distributor> listDistributors = service.listAll();
		model.addAttribute("listDistributors", listDistributors);
		
		return "index";
	}
	
	@RequestMapping("/new")
	public String showNewDistributorPage(Model model) {
		Distributor distributor = new Distributor();
		model.addAttribute("distributor", distributor);
		
		return "addnew_distributor";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveProduct(@ModelAttribute("distributor") Distributor distributor) {
		service.save(distributor);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{d_id}")
	public ModelAndView showEditDistributorPage(@PathVariable(name = "d_id") int d_id) {
		ModelAndView mav = new ModelAndView("edit_distributor");
		Distributor distributor = service.get(d_id);
		mav.addObject("distributor", distributor);
		
		return mav;
	}
	
	@RequestMapping("/delete/{d_id}")
	public String deleteDistributor(@PathVariable(name = "d_id") int d_id) {
		service.delete(d_id);
		return "redirect:/";		
	}
}
