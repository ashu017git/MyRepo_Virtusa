package com.virtusa.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Distributor {
	private Integer d_id;
	private String d_name;
	private long d_phno;
	private int product_id;
	private String productname;

	protected Distributor() {
	}
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)


	public Integer getD_id() {
		return d_id;
	}

	public void setD_id(Integer d_id) {
		this.d_id = d_id;
	}

	public String getD_name() {
		return d_name;
	}

	public void setD_name(String d_name) {
		this.d_name = d_name;
	}

	public long getD_phno() {
		return d_phno;
	}

	public void setD_phno(long d_phno) {
		this.d_phno = d_phno;
	}

	public int getProduct_id() {
		return product_id;
	}

	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}
	protected Distributor(Integer d_id, String d_name, long d_phno, int product_id, String productname) {
		super();
		this.d_id = d_id;
		this.d_name = d_name;
		this.d_phno = d_phno;
		this.product_id = product_id;
		this.productname = productname;
	}

//	protected Product(Integer id, String name, String brand, String madein, float price) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.brand = brand;
//		this.madein = madein;
//		this.price = price;
//	}
}
	
