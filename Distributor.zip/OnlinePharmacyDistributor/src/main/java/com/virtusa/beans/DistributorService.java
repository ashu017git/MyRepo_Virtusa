package com.virtusa.beans;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class DistributorService {

	@Autowired
	private DistributorRepository repo;
	
	public List<Distributor> listAll() {
		return repo.findAll();
	}
	
	public void save(Distributor product) {
		repo.save(product);
	}
	
	public Distributor get(Integer id) {
		return repo.findById(id).get();
	}
	
	public void delete(Integer id) {
		repo.deleteById(id);
	}
}
