package com.virtusa.beans;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@ComponentScan(basePackages = "com.virtusa.beans")
public class OnlinePharmacyDistributorApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePharmacyDistributorApplication.class, args);
	}

}
