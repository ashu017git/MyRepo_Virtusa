package com.virtusa.model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinepharmacySpring3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
