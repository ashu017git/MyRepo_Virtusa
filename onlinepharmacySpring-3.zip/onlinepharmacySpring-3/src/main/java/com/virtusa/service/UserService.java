package com.virtusa.service;
import org.springframework.security.core.userdetails.UserDetailsService;

import com.virtusa.beans.User;
import com.virtusa.web.UserRegistrationDto;


public interface UserService extends UserDetailsService{

	User save( UserRegistrationDto registartionDto);
}

