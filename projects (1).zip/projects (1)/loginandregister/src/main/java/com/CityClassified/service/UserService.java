package com.CityClassified.service;

import org.springframework.security.core.userdetails.UserDetailsService;


import com.CityClassified.beans.User;
import com.CityClassified.web.dto.UserRegistrationDto;



public interface UserService extends UserDetailsService{

	User save( UserRegistrationDto registartionDto);
}
