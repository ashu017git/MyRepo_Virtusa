package com.CityClassified.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.CityClassified.beans.Producttable;



@Repository
public interface ProductRepositry extends JpaRepository<Producttable, Long> {

}
