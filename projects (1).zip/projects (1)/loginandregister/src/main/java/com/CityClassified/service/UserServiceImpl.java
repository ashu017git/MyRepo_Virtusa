package com.CityClassified.service;

import java.util.ArrayList;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.CityClassified.beans.Role;
import com.CityClassified.beans.User;
import com.CityClassified.repo.UserRepository;
import com.CityClassified.web.dto.UserRegistrationDto;




@Service
public class UserServiceImpl implements UserService{
	
	private UserRepository userRepository;
	
	//private User userb;
	
	
	@Autowired
	public BCryptPasswordEncoder passwordEncoder;
	
	
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}


	@Override
	public User save(UserRegistrationDto registartionDto) {
				
	//	User registrationDto;
		User user=new User(registartionDto.getFirstName(),
				registartionDto.getLastName(),registartionDto.getEmail(),
				passwordEncoder.encode(registartionDto.getPassword()) , Arrays.asList(new Role(registartionDto.getRoles())));//
				
		     return userRepository.save(user);
	}


//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		// TODO Auto-generated method stub
//		return null;
//	}



	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	     
		User user=userRepository.findByEmail(username);
		
		if(user==null) {
			throw new UsernameNotFoundException("Invalid username or password");
		}
 return new org.springframework.security.core.userdetails.User(user.getEmail(),user.getPassword(),mapRolesToAuthorities(user.getRoles()));

	}
	
	
	
   private Collection<? extends GrantedAuthority> mapRolesToAuthorities(Collection<Role> roles){
	   
	   
	  
	   
	    List<SimpleGrantedAuthority> authorities = new ArrayList<>();
	     
	    for (Role role : roles) {
	        authorities.add(new SimpleGrantedAuthority(role.getName()));
	    }
	     
	    return authorities;
	   
 //return roles.stream().map(role -> new SimpleGrantedAuthority(role.getName())).collect(Collectors.toList());
	  
      }

}
