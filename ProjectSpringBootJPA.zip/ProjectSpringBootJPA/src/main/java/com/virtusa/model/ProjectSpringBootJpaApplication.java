package com.virtusa.model;

import org.springframework.boot.SpringApplication;


import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSpringBootJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSpringBootJpaApplication.class, args);
	}

}
