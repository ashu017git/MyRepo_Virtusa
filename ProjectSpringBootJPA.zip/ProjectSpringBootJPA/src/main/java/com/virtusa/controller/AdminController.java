package com.virtusa.controller;

import java.util.List;
 
 
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.PutMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.service.AdminService;
import com.virtusaa.model.Admin;  
 
@RestController  
public class AdminController   
{  
  
@Autowired  
AdminService adminService;  
   
@GetMapping("/admin")  
private List<Admin> getAllAdmin()   
{  
return adminService.getAllAdmin();  
}  
  
@GetMapping("/admin/{id}")  
private Admin getAdmin(@PathVariable("id") int id)   
{  
return adminService.getAdminById(id);  
}  
  
@DeleteMapping("/admin/{id}")  
private void deleteAdmin(@PathVariable("id") int id)   
{  
adminService.delete(id);  
}  

@PostMapping("/admin")  
private int saveAdmin(@RequestBody Admin admin)   
{  
adminService.saveOrUpdate(admin);  
return admin.getId();  
}  
  
@PutMapping("/admin")  
private Admin update(@RequestBody Admin admin)   
{  
adminService.saveOrUpdate(admin);  
return admin;  
}  
}  