package com.virtusa.service;

import java.util.ArrayList; 
 
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;

import com.virtusa.repository.AdminRepository;
import com.virtusaa.model.Admin;  
  
@Service  
public class AdminService   
{  
@Autowired  
AdminRepository adminRepository;  
  
public List<Admin> getAllAdmin()   
{  
List<Admin> admin = new ArrayList<Admin>();  

adminRepository.findAll().forEach(admin1 ->admin.add(admin1));  
return admin;  
}  
  
public Admin getAdminById(int id)   
{  
return adminRepository.findById(id).get();  
}  
  
public void saveOrUpdate(Admin admin)   
{  
	adminRepository.save(admin);  
}  
  
public void delete(int id)   
{  
	adminRepository.deleteById(id);  
}  
  
public void update(Admin admin, int id)   
{  
	adminRepository.save(admin);  
}


}  
