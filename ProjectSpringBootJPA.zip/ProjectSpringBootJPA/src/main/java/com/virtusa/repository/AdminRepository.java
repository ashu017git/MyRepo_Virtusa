package com.virtusa.repository;

import org.springframework.data.repository.CrudRepository;

import com.virtusaa.model.Admin;  

public interface AdminRepository extends CrudRepository<Admin, Integer>  {
	
}  
